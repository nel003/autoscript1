<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="e854cca7462a7096e7ddf3781badafa21489884b5cae4064ae3e551e6b8d2edf"
DB_SET="mysql:host=localhost;port=3306;dbname=OCS_PANEL"
DB_USER="root"
DB_PASS="Nel003"
?>