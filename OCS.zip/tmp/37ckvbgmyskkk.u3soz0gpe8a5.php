<div class="page-wrapper" style="min-height: 496px;">
  <div class="content container-fluid">
    <div class="row">
      <div class="col-xs-12">
        <h4 class="page-title">Success</h4>
      </div>
    </div>
    <div class="row">
      <?php if ($message): ?>     
        <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="icon fa fa-info"></i>
          <?php echo $message['data']; ?>
        </div>
      <?php endif; ?>
        <div class="col-md-4">
        </div>
        <div class="col-md-4">
          <div class="panel panel-noypi">
            <div class="panel-heading">
              <h3 class="panel-title"><i class="icon fa fa-server"></i> <?php echo $server->servername; ?> <?php echo $server->active==1?'':'( Locked )'; ?></h3>
            </div>
            <div class="panel-body">
                <table class="table table-white">
                    <tbody>
                        <tr>
                            <td>Username</td><td><?php echo $user->user; ?></td>
                        </tr>
                        <tr>
                            <td>Password</td><td><?php echo $user->pass; ?></td>
                        </tr>
                        <tr>
                            <td>Host Address</td><td><?php echo $server->host; ?></td>
                        </tr>
                        <tr>
                            <td>SSH Port</td><td><?php echo $server->openssh; ?></td>
                        </tr>
                        <tr>
                            <td>Dropbear Port</td><td><?php echo $server->dropbear; ?></td>
                        </tr>
                        <tr>
                            <td>Squid Port</td><td><?php echo $server->info; ?></td>
                        </tr>
                        <tr>
                            <td>Expired</td><td><?php echo \Webmin::exp_decode($user->expire); ?></td>
                        </tr>
                        <tr class="hidden-print">
                            <td colspan="2">
                                <a href="#" class="btn btn-primary btn-fill pull-right" onclick="print_report()">Print</a>
                                <a href="/home/member/server" class="btn btn-default btn-fill pull-left">Back</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
          </div>
        </div>
        <div class="col-md-4">
        </div>
    </div>
  </div>
</div>
