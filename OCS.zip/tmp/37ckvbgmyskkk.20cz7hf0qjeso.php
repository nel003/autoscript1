  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
                <?php if ($server->id): ?>
                    
                        <?php echo $server->servername; ?>
                    
                    <?php else: ?>
                        Add Server
                    
                <?php endif; ?>
      </h1>
      <ol class="breadcrumb">
                 <?php if ($server->id): ?>
                    
        <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/home/admin/server">List Server</a></li>
        <li class="active">Edit Server <?php echo $server->servername; ?></li>
                    
                    <?php else: ?>
                             <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/home/admin/server">List Server</a></li>
        <li class="active">Add Server</li>
                    
                <?php endif; ?>     
     
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

				<div class="alert alert-info alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i>Note:</h4>
Please, input correct vps password in label Root Password <br>
If wrong password server with can not be add.
              </div>
 		<div class="row">
        <div class="col-md-6">	
	        <?php if ($message): ?>     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i><?php echo $message['type']; ?></h4>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
        
		 <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title"> Server Settings</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->   

            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>Server Location</label>
                            <input class="form-control" placeholder="Singapore, Malaysia" name="country" type="text" value="<?php echo $server->country; ?>" required>
                        </div>
						<div class="form-group">
                            <label>ISP</label>
                            <input class="form-control" placeholder="Digital Ocean, Vultr" name="servername" type="text" value="<?php echo $server->servername; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>IP / Host</label>
                            <input class="form-control" placeholder="128.199.xxx.xx or www.example-server.com" name="host" type="text" value="<?php echo $server->host; ?>" required>
                        </div>
						<div class="form-group">
                            <label>SSH Port</label>
                            <input class="form-control" placeholder="22" name="openssh" type="text" value="<?php echo $server->openssh; ?>" required>
                        </div>
						<div class="form-group">
                            <label>Dropbear port</label>
                            <input class="form-control" placeholder="443" name="dropbear" type="text" value="<?php echo $server->dropbear; ?>" required>
                        </div>
						<div class="form-group">
                            <label>User limit</label>
                            <input class="form-control" placeholder="50" name="limitacc" type="text" value="<?php echo $server->limitacc; ?>" required>
                        </div>
						<div class="form-group">
                      <label>Squid Port</label>
                      <input class="form-control" placeholder="8080, 3128" name="info" type="text" value="<?php echo $server->info; ?>" required>
                        </div>
                 <div class="form-group">
                  <label>Torrent Allow ?</label>
                  <select class="form-control" name="badvpn" value="<?php echo $server->badvpn; ?>">
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                  </select>
                </div>
              
                        <div class="form-group">
                            <label>Price</label>
                            <div class="input-group">
                                <span class="input-group-addon">RM</span>
                                <input class="form-control" placeholder="10" name="price" type="number" step="1" value="<?php echo $server->price; ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Root Password</label>
                            <input class="form-control" placeholder="root" name="root_pass" type="password">
                        </div>
						
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
                       <?php if ($server->id): ?>
                            <?php if ($server->active==1): ?>
                                
                                    <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Lock</a>
                                
                                <?php else: ?>
                                    <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlock</a>
                                
                            <?php endif; ?>
                            <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                        <?php endif; ?>
                        <a href="/home/admin/server" class="btn btn-default">Back</a>
              </div>
            
            </form>
          </div>
          <!-- /.box -->
          </div>		           
         
     </div>	     
         
         
         
         
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->