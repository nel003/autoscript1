<div class="page-wrapper" style="min-height: 496px;">
  <div class="content container-fluid">

    <div class="row">
      <div class="col-xs-12">
        <h4 class="page-title">
          <?php echo $server->servername; ?> <?php echo $server->active==1?'':'( Locked )'; ?>
        </h4>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12">
        <div class="card-box">
          <?php if ($message): ?>     
            <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?php echo $message['data']; ?>
            </div>
          <?php endif; ?>
          <div class="box box-primary">
            <form role="form" action="<?php echo $URI; ?>" method="POST" class="form-horizontal">
              <div class="box-body">

              <div class="form-group">
                <label class="control-label col-lg-12">Username</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="Type Username" name="user" type="text" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Password</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="Type Password" name="pass" type="text" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Confirm Password</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="Type Re-enter Password" name="pass_confirmation" type="text" required>
                </div>
              </div>
              <div align="right">
                <button class="btn btn-primary">Create</button>
                <a href="/home/member/server" class="btn btn-default">Back</a>   
              </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>