    <title> Transparent Login Form Design </title>
    <!-- Stylesheets -->
    <link href="/view/css/style.css" rel="stylesheet" type="text/css">
          <div>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
</head>
    <body>
    <div class="account-box">
    <div class="account-wrapper">
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
    <?php endif; ?>
    <form action="/login" method="post">
    <div class="form-group form-focus">
    <div class="login-box">
    <img src="/view/images/avatar.png" class="avatar">
        <h1>Login Here</h1>
            <form>
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Username">
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password">
            <input type="submit" name="submit" value="Login">
            <a href="https://www.phcorner.net/threads/516768/">ɴᴇᴇᴅ ᴀɴ ᴀᴄᴄᴏᴜɴᴛ?</a>
            <div class="text-center">
              Made by Nel003 <i class="fa fa-heart text-red"></i>
            </form>                                                                                                                                            
                             </div>
                         </div>
                       </div>
                     </div>
                  </div>
               </div>
            </div>
        
        </div>
    
    </body>
</html>