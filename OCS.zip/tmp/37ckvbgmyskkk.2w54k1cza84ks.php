<div class="page-wrapper" style="min-height: 496px;">
  <div class="content container-fluid">
    <div class="row">
      <div class="col-xs-12">
        <h4 class="page-title">Server List</h4>
      </div>
    </div>
    <div class="row">
      <?php if ($message): ?>     
        <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="icon fa fa-info"></i>
          <?php echo $message['data']; ?>
        </div>
      <?php endif; ?>
      <?php foreach (($servers?:array()) as $server): ?>
        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="panel panel-noypi">
            <div class="panel-heading">
              <h3 class="panel-title"><i class="icon fa fa-server"></i> <?php echo $server->servername; ?> <?php echo $server->active==1?'':'( Locked )'; ?></h3>
            </div>
            <div class="panel-body">
              <table class="table table-white">
                  <tr>
                      <td><b>Location</b></td><td><?php echo $server->country; ?></td>
                  </tr>
                  <tr>
                      <td><b>Protocol</b></td><td>TCP</td>
                  </tr>
                  <tr>
                      <td><b>Host Address</b></td><td><?php echo $server->host; ?></td>
                  </tr>
                  <tr>
                      <td><b>OpenSSH Port</b></td><td><?php echo $server->openssh; ?></td>
                  </tr>
                  <tr>
                      <td><b>Dropbear Port</b></td><td><?php echo $server->dropbear; ?></td>
                  </tr>
                  <tr>
                      <td><b>Squid Port</b></td><td><?php echo $server->info; ?></td>
                  </tr>
                  <tr>
                      <td><b>Torrent Allow</b></td><td><?php echo $server->badvpn; ?></td>
                  </tr>
                  <tr>
                      <td><b>Validity</b></td><td>7 Days</td>
                  </tr>
              </table>
            </div>
            <div class="panel-footer" align="right">
              <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-primary"><i class="glyphicon glyphicon-hourglass"></i> Create Account</a>   
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>